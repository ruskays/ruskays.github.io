# Стартовый шаблон автора канала FrontCoder
Используется связка `Gulp` + `Pug` + `SCSS` + `BrowserSync` + `Linters`

## Установка
Склонировать репозиторий и выполнить npm install