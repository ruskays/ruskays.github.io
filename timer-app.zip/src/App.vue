<template>
  <div class="container">
    <timer-list></timer-list>
  </div>
</template>

<script>
import timerList from './components/timerList.vue';

export default {
  name: 'App',
  components: {
    timerList
  }
}
</script>

<style lang="scss">
  
</style>
