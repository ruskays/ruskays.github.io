 <?php 
/*
Template Name: О Компании
*/
?>

<?php get_header();?>
<div class="content">
        <section class="s-a-about">
          <div class="container">
		    <div class="breadcrambs-wrapper">
            <div class="breadcrambs">
              <?php kama_breadcrumbs() ?>
            </div>
			<a href="https://players.cupix.com/p/d1WsVWYg" target="_black" class="btn btn-border">3д тур</a>
			</div>
            <div class="a-about">
              <h1 class="sec-title"><?php the_title();?></h1>
              <div class="a-about-wrapper">
                <div class="a-about-text">
                  <?php the_content();?>

                </div>
                <div class="a-about-items">
                  <div class="a-about-items__top df">
                    <div class="a-about-item"><span>6 000м2</span>
                      <p>Производственных <br>площадей</p>
                    </div>
                    <div class="a-about-item"><span>>15</span>
                      <p>Лет успешной <br>работы</p>
                    </div>
                  </div>
                  <div class="a-about-items__bottom df">
                    <div class="a-about-item"><span>300+</span>
                      <p>Сданных объектов</p>
                    </div>
                    <div class="a-about-item"><span>85</span>
                      <p>Регионов присутствия</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
		<div class="s-btn-center">
			<div class="container">
			<a href="/news.html" class="btn btn-big btn-border">Наши Новости</a>
			</div>
			</div>
        <section class="s-form-b sa-form-b">
          <div class="container">
			
            <div class="form-b-wrapper">
              <div class="form-b">
                <div class="form-b-items">
                  <h2 class="form-b-title">Личная встреча - основа доверия!</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">Вы можете лично оценить качество продукции, посетив наше производство.</p>
                  <div class="form-b-group df sb a-form-b-group__block">
                    <div class="form-b-group__block"><a class="btn btn-big btn-big-call popup-view" href="#callme" data-popup="modal"><img src="img/general/phone.png" alt=""><span>Назначить встречу!</span></a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

<?php get_footer();?>