<?php
// Крошки
require_once 'functions/kama_breadcrumbs.php';


	define('MAG_THEME_ROOT', get_template_directory_uri());
	define('MAG_CSS_DIR', MAG_THEME_ROOT . '/assets/css');
	define('MAG_JS_DIR', MAG_THEME_ROOT . '/assets/js');
	define('MAG_IMG_DIR', MAG_THEME_ROOT . '/assets/img');
	define('MAG_DOC_DIR', MAG_THEME_ROOT . '/assets/docs/');

	add_action( 'wp_enqueue_scripts', function () {
		wp_enqueue_style( 'theme', get_stylesheet_uri() );
		wp_enqueue_style( 'styles', MAG_CSS_DIR . '/style.css' );
		wp_deregister_script('jquery');
		wp_enqueue_script( 'jquery', MAG_JS_DIR . '/jquery.js' );
		wp_enqueue_script( 'libs', MAG_JS_DIR . '/libs.js' );
		wp_enqueue_script( 'script', MAG_JS_DIR . '/script.js' );
		// wp_enqueue_script( 'script-name', get_template_directory_uri() .'/js/example.js', array(), '1.0', true );
	});
	
	add_theme_support('custom-logo');
	
	add_action('after_setup_theme', function() {
		add_theme_support('menus');
	});

	

	add_action( 'init', function (){
	
	

	//слайдер сертификатов на главной	
	register_post_type( 'serts', [
		'label'  => null,
		'labels' => [
			'name'               => 'Слайдер Сертификатов', 
			'singular_name'      => 'Слайдер Сертификатов', 
			'add_new'            => 'Добавить слайд', 
			'add_new_item'       => 'Добавление слайда', 
			'edit_item'          => 'Редактирование слайда', 
			'new_item'           => 'Новый слайд',
			'view_item'          => 'Смотреть слайд',
			'search_items'       => 'Искать слайд',
			'not_found'          => 'Не найдено', 
			'not_found_in_trash' => 'Не найдено в корзине',
			'parent_item_colon'  => '', 
			'menu_name'          => 'Слайдер Сертификатов',
		],
		'description'         => '',
		'public'              => true,
		'show_ui'             => null, // зависит от public
		'menu_position'       => null,
		'menu_icon'           => 'dashicons-format-image',
		'hierarchical'        => false,
		'supports'            => [ 'title', 'thumbnail'], 
	] );
});
function getSerts() {
		
	$args = array(
	'orderby'     => 'date',
	'order'       => 'ASC',
	'post_type'   => 'serts',
 );
	$serts = [];
	foreach(get_posts($args) as $post) {
			$sert = get_fields($post->ID);
			$sert['sertslide'] = $post->post_title;
			$serts[] = $sert;
	}
	
	return $serts;
}


	add_action( 'init', function (){
	
	

	//Наши проекты	
	register_post_type( 'ourprojects', [
		'label'  => null,
		'labels' => [
			'name'               => 'Наши проекты', 
			'singular_name'      => 'Наши проекты', 
			'add_new'            => 'Добавить проект', 
			'add_new_item'       => 'Добавление проекта', 
			'edit_item'          => 'Редактирование проекта', 
			'new_item'           => 'Новый проект',
			'view_item'          => 'Смотреть проект',
			'search_items'       => 'Искать проект',
			'not_found'          => 'Не найдено', 
			'not_found_in_trash' => 'Не найдено в корзине',
			'parent_item_colon'  => '', 
			'menu_name'          => 'Наши проекты',
		],
		'description'         => '',
		'public'              => true,
		'show_ui'             => null, // зависит от public
		'menu_position'       => null,
		'menu_icon'           => 'dashicons-admin-multisite',
		'hierarchical'        => false,
		'supports'            => [ 'title', 'thumbnail'], 
	] );
});
function getOurprojects() {
		
	$args = array(
	'orderby'     => 'date',
	'order'       => 'ASC',
	'post_type'   => 'ourprojects',
 );
	$ourprojects = [];
	foreach(get_posts($args) as $post) {
			$ourproject = get_fields($post->ID);
			$ourproject['projtitle'] = $post->post_title;
			$ourprojects[] = $ourproject;
	}
	
	return $ourprojects;
}

add_action( 'init', function (){
	
	

	//С кем мы сотрудничаем	
	register_post_type( 'partners', [
		'label'  => null,
		'labels' => [
			'name'               => 'С кем мы сотрудничаем', 
			'singular_name'      => 'Наши партнеры', 
			'add_new'            => 'Добавить фирму', 
			'add_new_item'       => 'Добавление фирмы', 
			'edit_item'          => 'Редактирование фирмы', 
			'new_item'           => 'Новый проект',
			'view_item'          => 'Смотреть фирму',
			'search_items'       => 'Искать проект',
			'not_found'          => 'Не найдено', 
			'not_found_in_trash' => 'Не найдено в корзине',
			'parent_item_colon'  => '', 
			'menu_name'          => 'С кем мы сотрудничаем',
		],
		'description'         => '',
		'public'              => true,
		'show_ui'             => null, // зависит от public
		'menu_position'       => null,
		'menu_icon'           => 'dashicons-buddicons-buddypress-logo',
		'hierarchical'        => false,
		'supports'            => [ 'title', 'thumbnail'], 
	] );
});
function getPartners() {
		
	$args = array(
	'orderby'     => 'date',
	'order'       => 'ASC',
	'post_type'   => 'partners',
 );
	$partners = [];
	foreach(get_posts($args) as $post) {
			$partner = get_fields($post->ID);
			$partner['projtitle'] = $post->post_title;
			$partners[] = $partner;
	}
	
	return $partners;
}

	add_action( 'init', function (){
	
	

	//Наши новости	
	register_post_type( 'ournews', [
		'label'  => null,
		'labels' => [
			'name'               => 'Наши новости', 
			'singular_name'      => 'Наши новости', 
			'add_new'            => 'Добавить новость', 
			'add_new_item'       => 'Добавление новости', 
			'edit_item'          => 'Редактирование проекта', 
			'new_item'           => 'Новая запись',
			'view_item'          => 'Смотреть запись',
			'search_items'       => 'Искать проект',
			'not_found'          => 'Не найдено', 
			'not_found_in_trash' => 'Не найдено в корзине',
			'parent_item_colon'  => '', 
			'menu_name'          => 'Наши новости',
		],
		'description'         => '',
		'public'              => true,
		'show_ui'             => null, // зависит от public
		'menu_position'       => null,
		'menu_icon'           => 'dashicons-embed-post',
		'hierarchical'        => false,
		'supports'            => [ 'title', 'thumbnail'], 
	] );
});
function getOurnews() {
		
	$args = array(
	'orderby'     => 'date',
	'order'       => 'ASC',
	'post_type'   => 'ournews',
 );
	$ournews = [];
	foreach(get_posts($args) as $post) {
			$ournew = get_fields($post->ID);
			$ournew['projtitle'] = $post->post_title;
			$ournews[] = $ournew;
	}
	
	return $ournews;
}

	add_action( 'init', function (){
	
	

	//Наши новости	
	register_post_type( 'ourquests', [
		'label'  => null,
		'labels' => [
			'name'               => 'Опросные листы', 
			'singular_name'      => 'Опросные листы', 
			'add_new'            => 'Добавить файл', 
			'add_new_item'       => 'Добавление файла', 
			'edit_item'          => 'Редактирование записи', 
			'new_item'           => 'Новая запись',
			'view_item'          => 'Смотреть запись',
			'search_items'       => 'Искать проект',
			'not_found'          => 'Не найдено', 
			'not_found_in_trash' => 'Не найдено в корзине',
			'parent_item_colon'  => '', 
			'menu_name'          => 'Опросные листы',
		],
		'description'         => '',
		'public'              => true,
		'show_ui'             => null, // зависит от public
		'menu_position'       => null,
		'menu_icon'           => 'dashicons-format-aside',
		'hierarchical'        => false,
		'supports'            => [ 'title', 'thumbnail'], 
	] );
});
function getOurquests() {
		
	$args = array(
	'orderby'     => 'date',
	'order'       => 'ASC',
	'post_type'   => 'ourquests',
 );
	$ourquests = [];
	foreach(get_posts($args) as $post) {
			$ourquest = get_fields($post->ID);
			$ourquest['questtitle'] = $post->post_title;
			$ourquests[] = $ourquest;
	}
	
	return $ourquests;
}

?>