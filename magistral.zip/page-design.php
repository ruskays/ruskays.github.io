<?php 
/*
Template Name: Проектирование
*/
?>

<?php get_header();?>
      <div class="content">
        <section class="s-design">
          <div class="container">
		  <div class="breadcrambs-wrapper">
            <div class="breadcrambs">
              <?php kama_breadcrumbs() ?>
              
            </div>
			<a href="https://players.cupix.com/p/d1WsVWYg" target="_black" class="btn btn-border">3д тур</a>
			</div>
            
            <div class="design">
              <div class="design-wrapper df sb">
                <div class="design-left">
                  <h1 class="sec-title">Проектирование</h1>
                  <div class="design-left__text">
                    <p>Завод Магистраль проектирует все виды котельных.</p>
                    <p><strong>Отопительные</strong> — для теплоснабжения, горячего водоснабжения жилых и общественных зданий.</p>
                    <p><strong>Производственные</strong> — для обеспечения технологических процессов горячей водой и паром. Проектируем ЦТП и ИТП, разрабатываем документацию в полном соответствии с требованиями ресурсоснабжающих организаций, с сопровождением в экспертизе и согласованиями.</p>
                  </div>
                </div>
                <div class="design-img"><img src="<?php echo MAG_IMG_DIR?>/general/des1.png" alt=""></div>
              </div>
              <div class="design-items df sb">
                <div class="design-item df">
                  <div class="design-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/des2.png" alt=""></div>
                  <div class="design-item__text"><span>Стабильно</span>
                    <p>100% наших проектов проходят экспертизу</p>
                  </div>
                </div>
                <div class="design-item df">
                  <div class="design-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/des3.png" alt=""></div>
                  <div class="design-item__text"><span>Экономно</span>
                    <p>Наработано множество типовых решений, что позволяет уменьшить стоимость проектирования.</p>
                  </div>
                </div>
                <div class="design-item df">
                  <div class="design-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/des4.png" alt=""></div>
                  <div class="design-item__text"><span>Удобно</span>
                    <p>Работаем по всей России и СНГ</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-process">
          <div class="container">
            <div class="process">
              <h2 class="sec-title">Процесс нашей работы</h2>
              <div class="process-wrapper df sb">
                <div class="process-item">
                  <div class="process-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/pro1.png" alt=""></div>
                  <p>Инженерные изыскания, геодезические, геологические</p>
                  <div class="process-item__a"><img src="<?php echo MAG_IMG_DIR?>/general/arL.png" alt=""></div>
                  <div class="process-item__a process-item__a--bottom process-item__imgDn"><img src="<?php echo MAG_IMG_DIR?>/general/arB.png" alt=""></div>
                </div>
                <div class="process-item">
                  <div class="process-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/pro2.png" alt=""></div>
                  <p>Получение технических условий, считаем нагрузки по объектам инженерного обеспечения, запрашиваем возможность на подключение</p>
                  <div class="process-item__a"><img src="<?php echo MAG_IMG_DIR?>/general/arL.png" alt=""></div>
                  <div class="process-item__a process-item__a--bottom process-item__imgDn"><img src="<?php echo MAG_IMG_DIR?>/general/arB.png" alt=""></div>
                </div>
                <div class="process-item">
                  <div class="process-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/pro3.png" alt=""></div>
                  <p>Разработка проекта, стадия «П» по постановлению Правительства РФ от 16.02.2008 N 87</p>
                  <div class="process-item__a process-item__a--bottom"><img src="<?php echo MAG_IMG_DIR?>/general/arB.png" alt=""></div>
                </div>
                <div class="process-item process-item__b process-item__5">
                  <div class="process-item__img process-item__b"><img src="<?php echo MAG_IMG_DIR?>/general/pro5.png" alt=""></div>
                  <p>Разработка рабочей документации, те чертежи, которые используются непосредственно в строительстве</p>
                </div>
                <div class="process-item process-item__b process-item__4">
                  <div class="process-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/pro4.png" alt=""></div>
                  <p>Прохождение экспертизы проекта государственной или коммерческой</p>
                  <div class="process-item__a process-item__a--rotate"><img src="<?php echo MAG_IMG_DIR?>/general/arL.png" alt=""></div>
                  <div class="process-item__a process-item__a--bottom process-item__imgDn"><img src="<?php echo MAG_IMG_DIR?>/general/arB.png" alt=""></div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-form-b sa-form-b sa-form-b-steam">
          <div class="container">
            <div class="form-b-wrapper">
              <form class="form-b form-img form-js form-test" enctype="multipart/form-data" method="post" id="form9" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items form-hide">
                  <h2 class="form-b-title">Необходимо качественное Проектирование котельной?</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">Получите КП в день обращения! Заполните небольшую форму, и мы с Вами свяжемся</p>
                  <div class="form-b-group df sb form-b-group__design">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      <input class="form-metka" type="hidden" name="metkaFF" value="НЕОБХОДИМО КАЧЕСТВЕННОЕ ПРОЕКТИРОВАНИЕ КОТЕЛЬНОЙ?">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" name="checked">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="form-img__wrapper design-form__img"><img src="<?php echo MAG_IMG_DIR?>/general/des1.png" alt=""></div>
                <div class="popup-form--wrap form-ok form-test-ok">
                  <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                </div>
              </form>
            </div>
          </div>
        </section>
      </div>
 

 <?php get_footer();?>