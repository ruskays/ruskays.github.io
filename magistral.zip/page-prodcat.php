<?php 
/*
Template Name: Категории Продукции
*/
?>

<?php get_header();?>
      <div class="content">
        <section class="s-prodcat">
          <div class="container">
		  <div class="breadcrambs-wrapper">
		  <div class="breadcrambs">
              <?php kama_breadcrumbs() ?>
        
      </div>
			<a href="https://players.cupix.com/p/d1WsVWYg" target="_black" class="btn btn-border">3д тур</a>
			</div>
            
            <div class="prodcat">
              <h2 class="sec-title">Продукция</h2>
              <div class="prodcat-items">
                <div class="plant-top df sb"><a class="plant-top__item" href="<?php echo home_url('/hot'); ?>"><img src="<?php echo MAG_IMG_DIR?>/general/p1new.png" alt="">
                    <p>Водогрейные котельные</p></a><a class="plant-top__item" href="<?php echo home_url('/steam'); ?>"><img src="<?php echo MAG_IMG_DIR?>/general/p2new.png" alt="">
                    <p>паровые котельные</p></a><a class="plant-top__item" href="<?php echo home_url('/outdoor'); ?>"><img src="<?php echo MAG_IMG_DIR?>/general/p3new.png" alt="">
                    <p>котлы наружного размещения</p></a><a class="plant-top__item" href="<?php echo home_url('/pgb'); ?>"><img src="<?php echo MAG_IMG_DIR?>/general/p4new.png" alt="">
                    <p>ПГБ,ГРПШ,ГРУ</p></a></div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-form-b s-form-b-bottom">
          <div class="container">
            <div class="form-b-wrapper form-b-bottom-wrapper">
              <form class="form-b form-b-bottom form-js form-test" enctype="multipart/form-data" method="post" id="form8" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items form-hide">
                  <h2 class="form-b-title">Бесплатная техническая консультация по индивидуальному заданию</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">И договоритесь о личной встрече на заводе или в вашем городе!</p>
                  <div class="form-b-phones df"><a href="tel:88005515707">8 (800) 551-57-07</a></div>
                  <div class="form-b-group df sb">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      <input class="form-metka" type="hidden" name="metkaFF" value="">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" name="checked">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="popup-form--wrap form-ok form-test-ok">
                  <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                </div>
              </form>
            </div>
          </div>
        </section>
      </div>
     
<?php get_footer();?>