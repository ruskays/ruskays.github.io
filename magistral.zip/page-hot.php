<?php 
/*
Template Name: Водогрейные котельные
*/
?>

<?php get_header();?>
      <div class="content">
        <section class="s-steam">
          <div class="container">
		  <div class="breadcrambs-wrapper">
		   <div class="breadcrambs">
              <?php kama_breadcrumbs() ?>
             </div>
			<a href="https://players.cupix.com/p/d1WsVWYg" target="_black" class="btn btn-border">3д тур</a>
			</div>
            
            <div class="steam">
              <div class="steam-wrapper df">
                <div class="steam-text">
                  <h2 class="sec-title">Водогрейные котельные</h2>
                  <div class="steam-text__wrapper">
                    <h3 class="steam-text__title">Блочно-модульная водогрейная котельная</h3>
                    <div class="steam-text__p">
                      <p>Представляет собой заводское изделие, готовое к работе, состоящее из одного или нескольких модулей. Количество блоков зависит от мощности и оснащения дополнительным оборудованием.</p>
                      <p>В состав модульной котельной входят котлы, горелки, насосные группы, автоматика для управления, фильтры, запорно-регулирующая арматура, водоподготовка, приборы учета. Наш завод производит котельные мощностью до 50 Мвт.</p>
                    </div>
                    <h4 class="steam-text__title">Главными преимуществами блочных котельных являются:</h4>
                    <div class="steam-items">
                      <div class="steam-item"><img src="<?php echo MAG_IMG_DIR?>/general/ok1.png" alt=""><span>не нужно возводить капитальное здание, в отличие от стационарных аналогов.</span></div>
                      <div class="steam-item"><img src="<?php echo MAG_IMG_DIR?>/general/ok1.png" alt=""><span>быстрый монтаж - котельная поставляется на объект в сборе.</span></div>
                      <div class="steam-item"><img src="<?php echo MAG_IMG_DIR?>/general/ok1.png" alt=""><span>простота согласования с контролирующими органами.</span></div>
                      <div class="steam-item"><img src="<?php echo MAG_IMG_DIR?>/general/ok1.png" alt=""><span>отсутствие обслуживающего персонала, в виду высокой степени автоматизации.</span></div>
                    </div>
                  </div>
                </div>
                <div class="banner-right steam-right">
                  <form class="form form-banner form-banner__smoke form-float form-js form-test" enctype="multipart/form-data" method="post" id="form10" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                    <div class="form-float__img"><img src="<?php echo MAG_IMG_DIR?>/general/redF.png" alt=""></div><span class="form-banner-title">Рассчитать котельную</span>
                    <hr class="form-banner-line">
                    <div class="form-banner-wrapper form-hide">
                      <div class="form-banner-group">
                        <input class="validate" type="text" placeholder="Имя" name="nameFF">
                      </div>
                      <div class="form-banner-group">
                        <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                      </div>
                      <div class="form-banner-group">
                        <input type="text" placeholder="Почта" name="emailFF">
                      </div>
                      <div class="form-banner-btn">
                        <button class="btn btn-banner-form form-button">Рассчитать</button>
                        <input class="form-metka" type="hidden" name="metkaFF" value="Рассчитать котельную">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                      </div>
                    </div>
                    <div class="form-b-radio popup-form__check" style="displaY:none"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" name="checked">
<span class="checkmark"></span>
</label> 
                    </div>
                    <div class="popup-form--wrap form-ok form-test-ok">
                    <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                  </div>
                  </form>
                  
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-fiel">
          <div class="container">
            <div class="fiel">
              <h2 class="sec-title">Виды используемого топлива</h2>
              <div class="fiel-items df sb">
                <div class="fiel-item">
                  <div class="fiel-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/f1.png" alt=""></div>
                  <p>Газ</p>
                </div>
                <div class="fiel-item">
                  <div class="fiel-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/f2.png" alt=""></div>
                  <p>Жидкое топливо</p>
                </div>
                <div class="fiel-item">
                  <div class="fiel-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/f3.png" alt=""></div>
                  <p>Твердое топливо</p>
                </div>
                <div class="fiel-item">
                  <div class="fiel-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/f4.png" alt=""></div>
                  <p>Сжиженные<br> углеводороды</p>
                </div>
                <div class="fiel-item">
                  <div class="fiel-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/f5.png" alt=""></div>
                  <p>Электричество</p>
                </div>
              </div>
              <div class="fiel-btn"><a class="btn btn-fiel" href="/projects.html">Посмотреть проекты</a></div>
            </div>
          </div>
        </section>
        <section class="s-tipes">
          <div class="container">
            <div class="tipes">
              <h2 class="sec-title">Типы котельных</h2>
              <div class="tipes-items df sb">
                <div class="tipes-item tipes-item__bgW">
                  <div class="tipes-item__top"><img src="<?php echo MAG_IMG_DIR?>/general/h1.png" alt=""></div>
                  <div class="tipes-item__text"><span class="title">пристроенные</span>
                    <p>Примыкают непосредственно к одной из наружных стен отапливаемого объекта.</p>
                  </div>
                </div>
                <div class="tipes-item tipes-item__bgW">
                  <div class="tipes-item__top"><img src="<?php echo MAG_IMG_DIR?>/general/h2.png" alt=""></div>
                  <div class="tipes-item__text"><span class="title">крышные</span>
                    <p>Размещаются капитальном помещении, построенном на крыше, либо в блочном исполнении на специальном основании на кровле.</p>
                  </div>
                </div>
                <div class="tipes-item tipes-item__bgW">
                  <div class="tipes-item__top"><img src="<?php echo MAG_IMG_DIR?>/general/h3.png" alt=""></div>
                  <div class="tipes-item__text"><span class="title">отдельностоящие</span>
                    <p>Могут быть размещены как в построенном для этой цели капитальном здании, так и в полностью готовом виде в блочном исполнении.</p>
                  </div>
                </div>
                <div class="tipes-item tipes-item__bgW">
                  <div class="tipes-item__top"><img src="<?php echo MAG_IMG_DIR?>/general/h4.png" alt=""></div>
                  <div class="tipes-item__text"><span class="title">передвижные</span>
                    <p>Транспортабельные на автоприцепе.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-form-b sa-form-b sa-form-b-steam">
          <div class="container">
            <div class="form-b-wrapper">
              <form class="form-b form-img form-js form-test" enctype="multipart/form-data" method="post" id="form6" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items form-hide">
                  <h2 class="form-b-title">Запросите коммерческое предложение!</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">И договоритесь о личной встрече на заводе или в вашем городе!</p>
                  <div class="form-b-group df sb">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      <input class="form-metka" type="hidden" name="metkaFF" value="ЗАПРОСИТЕ КОММЕРЧЕСКОЕ ПРЕДЛОЖЕНИЕ!">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="form-img__wrapper steam-form__img"><img src="<?php echo MAG_IMG_DIR?>/general/fr1.png" alt=""></div>
                <div class="popup-form--wrap form-ok form-test-ok">
                  <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                </div>
              </form>
            </div>
          </div>
        </section>
      </div>
 <?php get_footer();?>