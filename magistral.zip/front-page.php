<?php 
/*
Template Name: Главная
*/
?>

<?php get_header();?>
  <div class="content">
		<section class="s-3d">
			<div class="container">
			<a href="https://players.cupix.com/p/d1WsVWYg" target="_black" class="btn btn-border">3д тур</a>
			</div>
		</section>
        <section class="s-banner">
          <div class="container">
            <div class="banner df">
              <div class="banner-left">
                <h1 class="banner-left__title"><?php the_field('bannertitle');?> <strong><?php the_field('bannertitlered');?></strong></h1>
                <hr class="line">
                <div class="banner-left__items">
                  <div class="banner-left__item"><img src="<?php echo MAG_IMG_DIR?>/general/ok.png" alt=""><span><?php the_field('banneradvan1');?></span></div>
                  <div class="banner-left__item"><img src="<?php echo MAG_IMG_DIR?>/general/ok.png" alt=""><span><?php the_field('banneradvan2');?></span></div>
                  <div class="banner-left__item"><img src="<?php echo MAG_IMG_DIR?>/general/ok.png" alt=""><span><?php the_field('banneradvan3');?></span></div>
                  <div class="banner-left__item"><img src="<?php echo MAG_IMG_DIR?>/general/ok.png" alt=""><span><?php the_field('banneradvan4');?></span></div>
                </div>
              </div>
              <div class="banner-right">
                <form class="form form-banner form-js form-test" enctype="multipart/form-data" method="post" id="form3"><span class="form-banner-title" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">Рассчитать котельную</span>
                  <hr class="form-banner-line">
                  <div class="form-banner-wrapper form-hide">
                    <div class="form-banner-group">
                      <input class="validate" type="text" placeholder="Имя" name="nameFF">
                    </div>
                    <div class="form-banner-group">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-banner-group">
                      <input type="text" placeholder="Почта" name="emailFF">
                    </div>
                    <div class="form-banner-btn">
                      <button class="btn btn-banner-form form-button">Рассчитать</button>
                      <input class="form-metka" type="hidden" name="metkaFF" value="Рассчитать котельную">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                    <div class="form-b-radio popup-form__check" style="displaY:none"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" name="checked">
<span class="checkmark"></span>
</label> 
                    </div>
                  </div>
                  <div class="popup-form--wrap form-ok form-test-ok form-banner-ok">
                    <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </section>
        <section class="s-plant">
          <div class="container">
            <div class="plant">
              <div class="plant-top df sb"><a class="plant-top__item" href="<?php echo home_url('/hot'); ?>"><img src="<?php echo MAG_IMG_DIR?>/general/p1new.png" alt="">
                  <p>Водогрейные котельные</p></a><a class="plant-top__item" href="<?php echo home_url('/steam'); ?>"><img src="<?php echo MAG_IMG_DIR?>/general/p2new.png" alt="">
                  <p>паровые котельные</p></a><a class="plant-top__item" href="<?php echo home_url('/outdoor'); ?>"><img src="<?php echo MAG_IMG_DIR?>/general/p3new.png" alt="">
                  <p>котлы наружного размещения</p></a><a class="plant-top__item" href="<?php echo home_url('/pgb'); ?>"><img src="<?php echo MAG_IMG_DIR?>/general/p4new.png" alt="">
                  <p>ПГБ,ГРПШ,ГРУ</p></a></div>
              <div class="plant-center df sb">
                <div class="plant-center__left">
                  <h2 class="sec-title">Завод <strong>МАГИСТРАЛЬ</strong></h2>
                  <div class="plant-center__left--text">
                    <p>Более 15 лет группа компаний «МАГИСТРАЛЬ» является лидером рынка по производству блочно-модульных котельных установок, котлов наружного размещения, ПГБ, ГРПШ и ГРУ. Мы наращиваем темпы производства, постоянно повышая качество выпускаемой продукции, квалификацию персонала и уровень сервиса для клиента. </p>
                    <p>Главные приоритеты ГК «МАГИСТРАЛЬ» - это качество производимой продукции и максимально эффективное решение поставленных задач.</p>
                  </div>
                  <div class="plant-center__left--items df">
                    <div class="plant-center__left--item"><span>15 лет</span>
                      <p>«Магистраль» начал свою работу в 2005 году и является лидером в отрасли сегодня</p>
                    </div>
                    <div class="plant-center__left--item"><span>более 6000 м<sup>2</sup></span>
                      <p>Производственные мощности модернизируются из года в год</p>
                    </div>
                  </div>
                </div>
                <div class="plant-center__right"><img src="<?php echo MAG_IMG_DIR?>/general/plant-map.png" alt=""><a class="btn btn-plant custom-btn" href="<?php echo home_url('/projects'); ?>">Посмотреть готовые объекты с ценами </a></div>
              </div>
              <div class="plant-bottom df sb">
                <div class="plant-bottom__item">
                  <div class="img-circle"><img src="<?php echo MAG_IMG_DIR?>/general/p5.png" alt=""></div>
                  <p>Доставка <strong>по всей России</strong></p>
                </div>
                <div class="plant-bottom__item">
                  <div class="img-circle"><img src="<?php echo MAG_IMG_DIR?>/general/p6.png" alt=""></div>
                  <p><strong>Компетентный</strong> инженерный состав</p>
                </div>
                <div class="plant-bottom__item">
                  <div class="img-circle"><img src="<?php echo MAG_IMG_DIR?>/general/p7.png" alt=""></div>
                  <p>Собственный <strong>проектный отдел</strong></p>
                </div>
                <div class="plant-bottom__item">
                  <div class="img-circle"><img src="<?php echo MAG_IMG_DIR?>/general/p8.png" alt=""></div>
                  <p><strong>Без наценок</strong> по регионам</p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-days">
          <div class="container">
            <div class="days">
              <h2 class="sec-title">Готовая котельная за <strong>45 дней</strong></h2>
              <div class="days-wrapper">
                <div class="days-block">
                  <div class="days-item days-item__red"><img src="<?php echo MAG_IMG_DIR?>/general/d1.png" alt=""><span class="title">ШТАТНЫЙ ПРОЕКТНЫЙ ОТДЕЛ</span></div>
                  <div class="days-item"><span class="num">01</span>
                    <p>Разработаем коммерческое предложение в течении 48 часов</p>
                  </div>
                  <div class="days-item"><span class="num">02</span>
                    <p>Бесплатно спроектируем БМК согласно 87 постановлению</p>
                  </div>
                </div>
                <div class="days-block">
                  <div class="days-item days-item__red"><img src="<?php echo MAG_IMG_DIR?>/general/d2.png" alt=""><span class="title">ЛИЧНАЯ ВСТРЕЧА ПО ВСЕЙ РОССИИ</span></div>
                  <div class="days-item"><span class="num">03</span>
                    <p>Изготовим и интегрируем в общую систему теплоснабжения</p>
                  </div>
                  <div class="days-item"><span class="num">04</span>
                    <p>Оперативно доставим в любой регион России</p>
                  </div>
                </div>
                <div class="days-block">
                  <div class="days-item days-item__red"><img src="<?php echo MAG_IMG_DIR?>/general/d3.png" alt=""><span class="title">ОТЛАЖЕННАЯ ЛОГИСТИКА<br>ПО ВСЕЙ РОССИИ</span></div>
                  <div class="days-item"><span class="num">05</span>
                    <p>Качественно выполним монтажные и пусконаладочные работы</p>
                  </div>
                  <div class="days-item"><span class="num">06</span>
                    <p>Сопровождаем сдачу проекта в надзорные органы</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-form-b">
          <div class="container">
            <div class="form-b-wrapper">
              <form class="form-b form-js form-test" enctype="multipart/form-data" method="post" id="form4" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items form-hide">
                  <h2 class="form-b-title">Запросите коммерческое предложение!</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">И договоритесь о личной встрече на заводе или в вашем городе!</p>
                  <div class="form-b-group df sb">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      <input class="form-metka" type="hidden" name="metkaFF" value="коммерческое предложение">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked" >Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" name="checked">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="popup-form--wrap form-ok form-test-ok">
                  <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                </div>
              </form>
            </div>
          </div>
        </section>
        <section class="s-why">
          <div class="container">
            <div class="why">
              <h2 class="sec-title"><strong>Основные причины</strong></br> сотрудничать с нами</h2>
              <div class="why-wrapper df sb">
                <div class="why-item">
                  <div class="img-circle"><img src="<?php echo MAG_IMG_DIR?>/general/w1.png" alt=""></div><span class="title">Профессионализм</span>
                  <p>Средний опыт сотрудника не менее 5 лет в отрасли и множество спроектированных и произведенных котельных</p>
                </div>
                <div class="why-item">
                  <div class="img-circle"><img src="<?php echo MAG_IMG_DIR?>/general/w2.png" alt=""></div><span class="title">Проверенная надежность</span>
                  <p>Опыт участия и поставок согласно ФЗ о закупках. Государственные и оборонные заказы, сотрудничества с крупными коммерческими организациями</p>
                </div>
                <div class="why-item">
                  <div class="img-circle"><img src="<?php echo MAG_IMG_DIR?>/general/w3.png" alt=""></div><span class="title">Обоснованные цены</span>
                  <p>Делаем лучшее ценовое предложение на рынке</p>
                </div>
                <div class="why-item">
                  <div class="img-circle"><img src="<?php echo MAG_IMG_DIR?>/general/w4.png" alt=""></div><span class="title">Персональный подход</span>
                  <p>Консультирование от "А" до "Я" в режиме реального времени. Подбор согласно индивидуальным требованиям</p>
                </div>
                <div class="why-item">
                  <div class="img-circle"><img src="<?php echo MAG_IMG_DIR?>/general/w5.png" alt=""></div><span class="title">Принцип одного окна</span>
                  <p>Подбор оборудования, проектирование, изготовление, монтаж и запуск котельной осуществляется нашими специалистами</p>
                </div>
                <div class="why-item">
                  <div class="img-circle"><img src="<?php echo MAG_IMG_DIR?>/general/w6.png" alt=""></div><span class="title">Подбор документов</span>
                  <p>Разрабатываем и предоставляем необходимые документы для сдачи в эксплуатацию</p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-sert">
          <div class="container">
            <div class="sert df sb">
              <div class="sert-left">
                <h2 class="sec-title">Разрешительные и<br> производственные <strong>документы</strong></h2>
                <div class="sert-left__text">
                  <p>Компания «Магистраль» обладает всеми необходимыми сертификатами, разрешениями и свидетельствами, позволяющими вести производственную деятельность.</p>
                  <p>Все оборудование проходит своевременное техническое обслуживание и регулярно проверяется на износ.</p>
                </div>
              </div>
              <div class="sert-right">
                <div class="js-sert-nav">
                  <div class="js-sert-nav__prev prev">
                    <svg class="svg-sprite-icon icon-next prev-arrow">
                      <use xlink:href="<?php echo MAG_IMG_DIR?>/svg/symbol/sprite.svg#next"></use>
                    </svg>
                  </div>
                  <div class="js-sert-nav__next next">
                    <svg class="svg-sprite-icon icon-next next-arrow">
                      <use xlink:href="<?php echo MAG_IMG_DIR?>/svg/symbol/sprite.svg#next"></use>
                    </svg>
                  </div>
                </div>
                <div class="js-sert-slider">
                  <?php foreach(getSerts() as $sert):?> 
                  <?php 
                    $image = $sert['slideserts'];
                   if( !empty( $image ) ): ?>
                  <div class="sert-right__img"><img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"></div>
                  <?php endif; ?>
                  <?php endforeach; ?>               
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-partners">
          <div class="container">
            <div class="partners">
              <h2 class="sec-title">С кем <strong>мы сотрудничаем</strong></h2>
              <div class="partners-wrapper df sb">
                <?php foreach(getPartners() as $partner):?> 
                  <?php 
                    $image = $partner['parnterimg'];
                   if( !empty( $image ) ): ?>
                <div class="img-circle"><img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"></div>
                <?php endif; ?>
                  <?php endforeach; ?> 
                
              </div>
            </div>
          </div>
        </section>
        <section class="s-form-b s-form-b-bottom">
          <div class="container">
            <div class="form-b-wrapper form-b-bottom-wrapper">
              <form class="form-b form-b-bottom form-js form-test" enctype="multipart/form-data" method="post" id="form8" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items form-hide">
                  <h2 class="form-b-title">Бесплатная техническая консультация по индивидуальному заданию</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">И договоритесь о личной встрече на заводе или в вашем городе!</p>
                  <div class="form-b-phones df"><a href="tel:88005515707">8 (800) 551-57-07</a></div>
                  <div class="form-b-group df sb">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      <input class="form-metka" type="hidden" name="metkaFF" value="Бесплатная техническая консультация по индивидуальному заданию">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" name="checked">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="popup-form--wrap form-ok form-test-ok">
                  <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                </div>
              </form>
            </div>
          </div>
        </section>
      </div>

<?php get_footer();?>