      <footer class="footer">
        <div class="container">
          <div class="footer-wrapper df">
            <div class="logo"><?php the_custom_logo(); ?></div>
            <div class="footer-wrapper-right">
              <div class="footer-wrapper-right__top df sb">
                <div class="footer-wrapper-block">
                   <?php wp_nav_menu([
                        'menu' => 'Меню footer1',
                        'container'=> '',
                        'menu_class'      => '',
                      ]);?>
                 
                </div>
                <div class="footer-wrapper-block">
                  <?php wp_nav_menu([
                        'menu' => 'Меню footer2',
                        'container'=> '',
                        'menu_class'      => '',
                      ]);?>

                </div>
                <div class="footer-wrapper-block">
                  <div class="header-left__top-phone df fdc"><a class="phone-footer" href="tel:88005515707">8 (800) 551-57-07</a><span>Бесплатный звонок по РФ</span></div><a class="btn btn-footer popup-view" href="#callme" data-popup="modal">Заказать звонок</a>
                </div>
              </div>
              <div class="footer-wrapper-right__bottom">
                <p>© 2019 “МАГИСТРАЛЬ” | <a href="">Политика конфиденциальности</a></p>
              </div>
            </div>
          </div>
        </div>
      </footer>

     <!--popup form-->

      <div class="callme-popup">

        <div class="popup-close--2"></div>

        <div class="popup-form">

          <div class="popup-form--wrap ">

            <div class="popup-close"><span></span></div>

            

            <div class="popup__form">

              <form class="form-js" id="form_callme" enctype="multipart/form-data" method="post" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">

                <div class="popup-form__inputWrapper form-hide">
                  <div class="popup-form__input">
                  <div class="popup-form__title">Заказать звонок</div>
                  </div>
                  <div class="popup-form__input">

                    <input class="input-text validate" type="text" name="nameFF" placeholder="Имя">

                  </div>

                  <div class="popup-form__input">

                    <input class="input-text mask validate" type="text" name="telFF" placeholder="Введите ваш телефон">

                  </div>
    
                 

                  <div class="popup-form__btnWrapper">

                    <div class="popup-form__btn">

                      <div class="button btn form-button btn-brown"><span>Отправить</span></div>

                      <input class="button-submit" type="submit">

                      <input class="form-metka" type="hidden" name="metkaFF" value="Заказать звонок">

                      <input class="form-city" type="hidden" name="cityFF" value="">

                    </div>

                    <div class="popup-form__check">Нажимая на кнопку "Отправить" я соглашаюсь с <a href="/Polozhenie.pdf" target="_blank" rel="nofollow">Положением о персональных данных</a>, <a href="/Politika.pdf" target="_blank" rel="nofollow">Политикой конфиденциальности</a> и <a href="/Soglashenie.pdf" target="_blank" rel="nofollow">Пользовательским соглашением</a>.

                      <label class="confidencial__checked">

                        <input type="checkbox" name="checked" value="Согласен" checked=""><span></span>

                      </label>

                    </div>

                  </div>

                </div>
                  <div class="popup-form--wrap form-ok popup-form-ok">

                    <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>

                  </div>
              </form>

            </div>

          </div>


        </div>

      </div>



    </div>
 
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(72682954, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/72682954" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-196417685-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-196417685-1');
</script>


<?php wp_footer();?>
  </body>
</html>