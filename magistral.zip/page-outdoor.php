<?php 
/*
Template Name: Котлы наружного размещения
*/
?>

<?php get_header();?>
      <div class="content">
        <section class="s-steam s-outdoor">
          <div class="container">
		  <div class="breadcrambs-wrapper">
		  <div class="breadcrambs">
              <?php kama_breadcrumbs() ?>
        
      </div>
			<a href="https://players.cupix.com/p/d1WsVWYg" target="_black" class="btn btn-border">3д тур</a>
			</div>
            
            <div class="steam outdoor">
              <div class="steam-wrapper df outdoor-wrapper">
                <div class="steam-text outdoor-text">
                  <h1 class="sec-title">Котлы наружного размещения</h1>
                  <div class="steam-text__wrapper">
                    <div class="steam-text__p">
                      <p>Котлы наружного размещения нашего производства широко распространены по всей России. Многие компании и организации уже оценили серьезный экономический эффект от внедрения этого вида отопительного оборудования.</p>
                    </div>
                    <div class="steam-items">
                      <div class="steam-item"><img src="<?php echo MAG_IMG_DIR?>/general/ok1.png" alt=""><span>В 2 раза дешевле котельной!</span></div>
                      <div class="steam-item"><img src="<?php echo MAG_IMG_DIR?>/general/ok1.png" alt=""><span>Мощность — от 50 до 800 кВт</span></div>
                      <div class="steam-item"><img src="<?php echo MAG_IMG_DIR?>/general/ok1.png" alt=""><span>Напрямую от производителя</span></div>
                      <div class="steam-item"><img src="<?php echo MAG_IMG_DIR?>/general/ok1.png" alt=""><span>На базе одного, двух или трех котлов</span></div>
                      <div class="steam-item"><img src="<?php echo MAG_IMG_DIR?>/general/ok1.png" alt=""><span>Исполнение на заказ под конкретные задачи</span></div>
                      <div class="steam-item"><img src="<?php echo MAG_IMG_DIR?>/general/ok1.png" alt=""><span>Возможность диспетчеризации</span></div>
                    </div>
                  </div>
                </div>
                <div class="banner-right steam-right outdoor-right">
                  <form class="form form-banner form-banner__smoke form-float form-banner__outdoor form-js form-hide form-test" enctype="multipart/form-data" method="post" id="form7" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                    <div class="form-float__img"><img src="<?php echo MAG_IMG_DIR?>/general/redF.png" alt=""></div><span class="form-banner-title">Рассчитать котельную</span>
                    <hr class="form-banner-line">
                    <div class="form-banner-wrapper">
                      <div class="form-banner-group">
                        <input class="validate" type="text" placeholder="Имя" name="nameFF">
                      </div>
                      <div class="form-banner-group">
                        <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                      </div>
                      <div class="form-banner-group">
                        <input type="text" placeholder="Почта" name="emailFF">
                      </div>
                      <div class="form-banner-btn">
                        <button class="btn btn-banner-form form-button">Рассчитать</button>
                        <input class="form-metka" type="hidden" name="metkaFF" value="Рассчитать котельную">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                      </div>
                      <div class="form-b-radio popup-form__check" style="displaY:none"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" name="checked">
<span class="checkmark"></span>
</label> 
                      </div>
                    </div>
                  </form>
                  <div class="popup-form--wrap form-ok form-test-ok">
                    <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-done-projects">
          <div class="container">
            <h2 class="sec-title">Выполненные обьекты</h2>
            <div class="done-projects df sb">
              <div class="done-projects__item">
                <div class="done-projects__item--img"><img src="<?php echo MAG_IMG_DIR?>/general/dkot1.png" alt=""></div>
                <div class="done-projects__item--text"><span class="title">Детский сад</span>
                  <p class="town">600кВт</p>
                </div>
              </div>
              <div class="done-projects__item">
                <div class="done-projects__item--img"><img src="<?php echo MAG_IMG_DIR?>/general/dkot2.png" alt=""></div>
                <div class="done-projects__item--text"><span class="title">Жилой дом</span>
                  <p class="town">800кВт</p>
                </div>
              </div>
              <div class="done-projects__item">
                <div class="done-projects__item--img"><img src="<?php echo MAG_IMG_DIR?>/general/dkot3.png" alt=""></div>
                <div class="done-projects__item--text"><span class="title">Производственный цех</span>
                  <p class="town">100кВт</p>
                </div>
              </div>
              <div class="done-projects__item">
                <div class="done-projects__item--img"><img src="<?php echo MAG_IMG_DIR?>/general/dkot4.png" alt=""></div>
                <div class="done-projects__item--text"><span class="title">Склад промтоваров</span>
                  <p class="town">400кВт</p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-advantage">
          <div class="container">
            <div class="advantage">
              <h2 class="sec-title">Преимущества</h2>
              <div class="advantage-items">
                <div class="advantage-item">
                  <div class="advantage-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/ad1.png" alt=""></div>
                  <div class="advantage-item__text"><span class="title">Экономичность и эффективность</span>
                    <hr class="line">
                    <p>Котел наружного размещения не только стоит дешевле котельной, но и уменьшает траты на обслуживание теплосетей!</p>
                  </div>
                </div>
                <div class="advantage-item">
                  <div class="advantage-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/ad2.png" alt=""></div>
                  <div class="advantage-item__text"><span class="title">Изготовление на заказ</span>
                    <hr class="line">
                    <p>Комплектация полностью зависит от задач, поставленных заказчиком. Хватит переплачивать за ненужный функционал!</p>
                  </div>
                </div>
                <div class="advantage-item">
                  <div class="advantage-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/ad3.png" alt=""></div>
                  <div class="advantage-item__text"><span class="title">Значительные меньшие габариты</span>
                    <hr class="line">
                    <p>КВСН значительно меньше котельной аналогичной мощности. Такому котлу достаточно упрощенного фундамента!</p>
                  </div>
                </div>
                <div class="advantage-item">
                  <div class="advantage-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/ad4.png" alt=""></div>
                  <div class="advantage-item__text"><span class="title">Простота и удобство конструкции</span>
                    <hr class="line">
                    <p>Металлический корпус обеспечивает защиту котла наружного размещения отвоздействия окружающей среды.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-fiel">
          <div class="container">
            <div class="fiel">
              <h2 class="sec-title">Виды используемого топлива</h2>
              <div class="fiel-items df sb">
                <div class="fiel-item">
                  <div class="fiel-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/f1.png" alt=""></div>
                  <p>Газ</p>
                </div>
                <div class="fiel-item">
                  <div class="fiel-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/f2.png" alt=""></div>
                  <p>Жидкое топлево</p>
                </div>
                <div class="fiel-item">
                  <div class="fiel-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/f3.png" alt=""></div>
                  <p>Твердое топливо</p>
                </div>
                <div class="fiel-item">
                  <div class="fiel-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/f4.png" alt=""></div>
                  <p>Сжиженные<br> углеводороды</p>
                </div>
                <div class="fiel-item">
                  <div class="fiel-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/f5.png" alt=""></div>
                  <p>Электричество</p>
                </div>
              </div>
              <div class="fiel-btn"><a class="btn btn-fiel" href="/projects.html">Посмотреть проекты</a></div>
            </div>
          </div>
        </section>
        <section class="s-form-b sa-form-b">
          <div class="container">
            <div class="form-b-wrapper">
              <form class="form-b form-img form-js form-hide form-test" enctype="multipart/form-data" method="post" id="form11" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items">
                  <h2 class="form-b-title">Запросите коммерческое предложение!</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">И договоритесь о личной встрече на заводе или в вашем городе!</p>
                  <div class="form-b-group df sb">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      
                      <input class="form-metka" type="hidden" name="metkaFF" value="Запросите коммерческое предложение">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" name="checked">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="form-img__wrapper outdoor-img__wrapper"><img src="<?php echo MAG_IMG_DIR?>/general/ph.png" alt=""></div>
              </form>
              <div class="popup-form--wrap form-ok form-test-ok">
                <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
              </div>
            </div>
          </div>
        </section>
      </div>
<?php get_footer();?>