 <?php 
/*
Template Name: Наши Новости
*/
?>

<?php get_header();?>
 <div class="content">
        <section class="s-projects">
          <div class="container">
			<div class="breadcrambs-wrapper">
            <div class="breadcrambs">
              <?php kama_breadcrumbs() ?>
            </div>
			<a href="https://players.cupix.com/p/d1WsVWYg" target="_black" class="btn btn-border">3д тур</a>
			</div>
            
            <div class="projects">
              <h2 class="sec-title">Наши проекты</h2>
              <div class="projects-items">

                <?php foreach(getOurprojects() as $ourproject):?> 
                <div class="projects-item">
                  <div class="projects-item__img">
                    <?php 
                    $image = $ourproject['projimg'];
                   if( !empty( $image ) ): ?>
                    <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
                    <?php endif; ?>
                  </div>
                  <div class="projects-item__text"><span class="title"><?php echo $ourproject['projtitle'];?></span><span class="fuel">Топливо – <?php echo $ourproject['projfield'];?></span><span class="town">г.<?php echo $ourproject['projtown'];?></span>
                    <div class="projects-item__price"><span class="price-title">Цена:</span><span class="num"> <?php echo $ourproject['projprice'];?> руб.</span></div>
                  </div>
                </div>
                <?php endforeach; ?> 

              
              
             
              </div>
            </div>
          </div>
        </section>
        <section class="s-form-b s-form-b-bottom">
          <div class="container">
            <div class="form-b-wrapper form-b-bottom-wrapper">
              <form class="form-b form-b-bottom form-js form-test" enctype="multipart/form-data" method="post" id="form8" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items form-hide">
                  <h2 class="form-b-title">Бесплатная техническая консультация по индивидуальному заданию</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">И договоритесь о личной встрече на заводе или в вашем городе!</p>
                  <div class="form-b-phones df"><a href="tel:88005515707">8 (800) 551-57-07</a></div>
                  <div class="form-b-group df sb">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      <input class="form-metka" type="hidden" name="metkaFF" value="БЕСПЛАТНАЯ ТЕХНИЧЕСКАЯ КОНСУЛЬТАЦИЯ ПО ИНДИВИДУАЛЬНОМУ ЗАДАНИЮ">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" name="checked">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="popup-form--wrap form-ok form-test-ok">
                  <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                </div>
              </form>
            </div>
          </div>
        </section>
      </div>

<?php get_footer();?>