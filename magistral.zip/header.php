<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo('charset')?>">
    <title>Строительство блочно-модульных котельных | Магистраль</title><!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE = edge"><![endif]-->
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="keywords" content="<?php the_field('keywords')?>">
     <meta name="description" content="<?php the_field('descriprion')?>">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&amp;display=swap" rel="stylesheet">
  <!--[if lt IE 9]>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv-printshiv.min.js"></script><![endif]-->
<script>(function(w, c){(w[c]=w[c]||[]).push(function(){new zTracker({"id":"958fa4d0bf7ec852a33d74c686d097e56270","metrics":{"metrika":"72682954"}});});})(window, "zTrackerCallbacks");</script>
<script async id="zd_ct_phone_script" src="https://my.zadarma.com/js/ct_phone.min.js"></script>
<script src="//code-ya.jivosite.com/widget/EbYrAIha3P" async></script>

<?php wp_head();?>

  </head>
  <body class="index-page">
    <div class="wrapper">
      <header class="header">
        <div class="container">
          <div class="header-wrapper df sb"><span class="top-title">Завод промышленного газового оборудования</span><?php the_custom_logo(); ?>
            <div class="header-left">
              <div class="header-left__top df"><span class="title">Завод промышленного газового оборудования</span><a class="btn popup-view" href="#callme" data-popup="modal">Заказать звонок</a>
                <div class="header-left__top-phone df fdc"><a href="tel:88005515707">8 (800) 551-57-07</a><span>Бесплатный звонок по РФ</span></div>
              </div>
              <div class="header-left__bottom">
                <div class="sandwich-wrapper">
                  <div class="sandwich"><span class="sandwich-line"></span></div>
                </div>
                <div class="nav-wrapper">
                  <nav>
                  
                      <?php wp_nav_menu([
                        'menu' => 'Меню Header',
                        'container'=> '',
                        'menu_class'      => '',
                      ]);?>
                    
                  </nav><a class="btn btn-mob popup-view" href="#callme" data-popup="modal">Заказать звонок</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>