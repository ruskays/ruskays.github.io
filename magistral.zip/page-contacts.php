<?php 
/*
Template Name: Контакты
*/
?>

<?php get_header();?>
      <div class="content">
        <section class="s-contact">
          <div class="container">
		  <div class="breadcrambs-wrapper">
		   <div class="breadcrambs">
              <?php kama_breadcrumbs() ?>

       
      </div>
			
			</div>
           
          </div>
          <div class="contact df">
            <div class="map"><iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3Ac649ef156b88f8553214ad9330e167f35fa8e7397f93290730dd7efb091db174&amp;source=constructor" width="100%" height="445" frameborder="0"></iframe></div>
            <div class="contact-info">
              <h1 class="sec-title">Контакты</h1>
              <div class="contact-info__items">
                <div class="contact-info__item"><a class="df" href="tel:+78005515707"><img src="<?php echo MAG_IMG_DIR?>/general/pho.png" alt="">
                    <p>8 (800) 551-57-07<strong>Бесплатно по РФ</strong></p></a>
<a class="df" href="tel:+74996776232"><img src="<?php echo MAG_IMG_DIR?>/general/pho.png" alt=""><p>8 (499) 677-62-32</p></a></div>
                <div class="contact-info__item df"><img src="<?php echo MAG_IMG_DIR?>/general/loc.png" alt="">
                  <p>Саратовская обл., г. Энгельс-2, территория Мясокомбинат</p>
                </div>
                <div class="contact-info__item"><a class="df" href="mailto:zavod@gkmagistral.ru"><img src="<?php echo MAG_IMG_DIR?>/general/mail.png" alt="">
                    <p>zavod@gkmagistral.ru</p></a></div>
                <div class="contact-info__item df"><img src="<?php echo MAG_IMG_DIR?>/general/time.png" alt="">
                  <p>09:00 — 18:00 (ПН-ПТ) Выходной (СБ-ВС)</p>
                </div>
              </div>
             <!-- <div class="contact-info__cart"><span>Карточка товара: </span><a href="#">Смотреть</a></div>-->
            </div>
          </div>
        </section>
        <section class="s-form-b s-form-b-bottom">
          <div class="container">
            <div class="form-b-wrapper form-b-bottom-wrapper">
              <form class="form-b form-b-bottom form-js form-test" enctype="multipart/form-data" method="post" id="form2" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items form-hide">
                  <h2 class="form-b-title">Хотите задать нам вопрос?</h2>
                  <hr class="form-b-line">
                  <div class="form-b-group df sb form-b-group--contact">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <input type="text" placeholder="E-mail" name="emailFF">
                    </div>
                    <div class="form-b-group__block">
                      <input type="text" placeholder="Ваш вопрос" name="questFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      <input class="form-metka" type="hidden" name="metkaFF" value="Форма Задать вопрос">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" class='input' name="checked">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="popup-form--wrap form-ok form-test-ok">
                  <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                </div>
              </form>
            </div>
          </div>
        </section>
      </div>
 
  <?php get_footer();?>