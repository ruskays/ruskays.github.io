<?php 
/*
Template Name: Опросные листы
*/
?>

<?php get_header();?>
      <div class="content">
        <section class="s-question">
          <div class="container">
		  <div class="breadcrambs-wrapper">
		  <div class="breadcrambs">
              <?php kama_breadcrumbs() ?>
        
      </div>
			<a href="https://players.cupix.com/p/d1WsVWYg" target="_black" class="btn btn-border">3д тур</a>
			</div>
            
            <div class="question">
              <h1 class="sec-title">Опросные листы</h1>
              <div class="question-items df sb">

              <?php foreach(getOurquests() as $ourquest):?> 
                <div class="question-item df">
                  <a class="question-item__link" href="<?php echo $ourquest['questfile'];?>">
                    <div class="question-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/word.png" alt=""></div>
                    <p><?php echo $ourquest['questtitle'];?> </p>
                  </a>
                </div>
               <?php endforeach; ?> 
                
               
              </div>
            </div>
          </div>
        </section>
        <section class="s-form-b sa-form-b sa-form-b-steam">
          <div class="container">
            <div class="form-b-wrapper">
              <form class="form-b form-img form-js form-test" enctype="multipart/form-data" method="post" id="form6" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items form-hide">
                  <h2 class="form-b-title">Запросите коммерческое предложение!</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">И договоритесь о личной встрече на заводе или в вашем городе!</p>
                  <div class="form-b-group df sb">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      <input class="form-metka" type="hidden" name="metkaFF" value="ЗАПРОСИТЕ КОММЕРЧЕСКОЕ ПРЕДЛОЖЕНИЕ">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="form-img__wrapper steam-form__img"><img src="<?php echo MAG_IMG_DIR?>/general/fr1.png" alt=""></div>
                <div class="popup-form--wrap form-ok form-test-ok">
                  <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                </div>
              </form>
            </div>
          </div>
        </section>
      </div>
      <?php get_footer();?>