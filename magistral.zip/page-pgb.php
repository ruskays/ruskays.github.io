<?php 
/*
Template Name: ПГБ, ГРПШ, ГРУ
*/
?>

<?php get_header();?>
      <div class="content">
        <section class="s-pgb">
          <div class="container">
		  <div class="breadcrambs-wrapper">
		  <div class="breadcrambs">
              <?php kama_breadcrumbs() ?>
        
      </div>
			<a href="https://players.cupix.com/p/d1WsVWYg" target="_black" class="btn btn-border">3д тур</a>
			</div>
            
            <div class="pgb">
              <h2 class="sec-title">ПГБ, ГРПШ, ГРУ</h2>
              <div class="pgb-items">
                <div class="pgb-item df">
                  <div class="pgb-item__text">
                    <p>Газорегуляторные пункты и установки предназначены для редуцирования природного газа по ГОСТ 5542-87 в газораспределительных сетях, автоматического поддержания давления на заданном уровне не зависимо от из менения расхода и входного давления, и автоматического прекращения подачи газа при аварийных повышениях или понижениях давления сверх заданных пределов, а также коммерческого учета объёма газа при использовании различных типов счётчиков газа.</p>
                  </div>
                  <div class="pgb-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/pgb1.png" alt=""></div>
                </div>
                <div class="fiel-btn pgb-btn"><a class="btn btn-fiel popup-view" href="#callme" data-popup="modal">Получить индивидуальный расчет</a></div>
                <div class="pgb-item df pgb-item-2">
                  <div class="pgb-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/pgb2.png" alt=""></div>
                  <div class="pgb-item__text">
                    <p><strong>Пункт газорегуляторный блочный (ПГБ)</strong> — предназначен для редуцирования газа высокого давления первой категории (от 0,6 МПа до 1,2 МПа) и среднего давления (от 0,3 МПа до 0,005 МПа) на требуемое, и автоматического отключения подачи газа при повышении значений, а также для коммерческого учета расхода газа.</p>
                    <p>Готовое изделие представляет собой утепленный металлический блок-бокс, внутри которого смонтировано технологическое оборудование. Дополнительно оснащается телеметрией и обогревом. Весь комплекс работ осуществляется на основании технических условий и сертификатов соответствия ГОСТ Р. с учетом пожеланий каждого из заказчиков.</p>
                  </div>
                </div>
                <div class="pgb-item df">
                  <div class="pgb-item__text">
                    <p><strong>Газорегуляторные пункты шкафные (ГРПШ)</strong> —Готовое изделие представляет собой металлический шкаф, внутри которого смонтировано технологическое оборудование. Размещается на улице и может  оснащатся обогревом. Каждое изделие проходит многоэтапный контроль качества, предназначены для работы в системах газоснабжения с диапазоном входных давлений от 0.025 до 1.2 МПа, расходами газа до30.000 м3/ч. и диаметрами труб до 200 мм.</p>
                    <p>Весь комплекс работ осуществляется на основании технических условий и сертификатов соответствия ГОСТ Р. с учетом пожеланий каждого из заказчиков.</p>
                  </div>
                  <div class="pgb-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/pgb3.png" alt=""></div>
                </div>
                <div class="pgb-item df pgb-item-2">
                  <div class="pgb-item__img"><img src="<?php echo MAG_IMG_DIR?>/general/pgb4.png" alt=""></div>
                  <div class="pgb-item__text">
                    <p>Газорегуляторные установки (ГРУ) — это комплекс технологического оборудования и устройств,предназначены для работы в системах газоснабжения с диапазоном входных давлений от 0.025 до 1.2 МПа, расходами газа до 30.000 м3/ч. и диаметрами труб до 200 мм.</p>
                    <p>ГРУ может использоваться как устройство для автономной работы , а так же как составная часть более крупной системы газораспределения. Газорегуляторная установка — тип газорегуляторного пункта, для которого характерны монтаж оборудования на раме и размещение в помещении, в котором расположена газоиспользующая установка, или в помещении, соединенном с ним открытым проемом. Весь комплекс работ осуществляется на основании технических условий и сертификатов соответствия ГОСТ Р. с учетом пожеланий каждого из заказчиков.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-done-projects">
          <div class="container">
            <h2 class="sec-title">Выполненные обьекты</h2>
            <div class="done-projects df sb">
              <div class="done-projects__item">
                <div class="done-projects__item--img pgb-done"><img src="<?php echo MAG_IMG_DIR?>/general/dpgb1.png" alt=""></div>
                <div class="done-projects__item--text"><span class="title">ПГБ-16-2НУ1</span>
                  <p class="town">г.Краснодар</p>
                </div>
              </div>
              <div class="done-projects__item">
                <div class="done-projects__item--img pgb-done"><img src="<?php echo MAG_IMG_DIR?>/general/dpgb2.png" alt=""></div>
                <div class="done-projects__item--text"><span class="title">ПГБ-16-2НУ1</span>
                  <p class="town">г.Воронеж</p>
                </div>
              </div>
              <div class="done-projects__item">
                <div class="done-projects__item--img pgb-done"><img src="<?php echo MAG_IMG_DIR?>/general/dpgb3.png" alt=""></div>
                <div class="done-projects__item--text"><span class="title">ГРПШ-13-2НУ1</span>
                  <p class="town">г.Клин</p>
                </div>
              </div>
              <div class="done-projects__item">
                <div class="done-projects__item--img pgb-done"><img src="<?php echo MAG_IMG_DIR?>/general/dpgb4.png" alt=""></div>
                <div class="done-projects__item--text"><span class="title">ГРПШ-05-2У1</span>
                  <p class="town">г. Екатеринбург</p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-form-b sa-form-b">
          <div class="container">
            <div class="form-b-wrapper">
              <form class="form-b form-img form-js  form-test" enctype="multipart/form-data" method="post" id="form1" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items form-hide">
                  <h2 class="form-b-title">Запросите коммерческое предложение!</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">И договоритесь о личной встрече на заводе или в вашем городе!</p>
                  <div class="form-b-group df sb">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      <input class="form-metka" type="hidden" name="metkaFF" value="Запросите коммерческое предложение">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" name="checked" checked="checked" class="input">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="form-img__wrapper"><img src="<?php echo MAG_IMG_DIR?>/general/pgb-form.png" alt=""></div>
                
                <div class="popup-form--wrap form-ok form-test-ok">
                <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
              </div>
              </form>
              
            </div>
          </div>
        </section>
      </div>
    
<?php get_footer();?>