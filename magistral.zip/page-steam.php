<?php 
/*
Template Name: Паровые котельные
*/
?>

<?php get_header();?>
      <div class="content">
        <section class="s-steam">
          <div class="container">
		  <div class="breadcrambs-wrapper">
		  <div class="breadcrambs">
              <?php kama_breadcrumbs() ?>
        
              </div>
			<a href="https://players.cupix.com/p/d1WsVWYg" target="_black" class="btn btn-border">3д тур</a>
			</div>
            
            <div class="steam">
              <div class="steam-wrapper df">
                <div class="steam-text">
                  <h2 class="sec-title">Паровые котельные</h2>
                  <div class="steam-text__wrapper">
                    <h3 class="steam-text__title">Блочно-модульные паровые котельные</h3>
                    <div class="steam-text__p">
                      <p>- это изделия заводской готовности. Их главная задача – выработка пара на различные промышленные нужды.</p>
                      <p>Паровые котельные вырабатывают пар, который используется на производстве, например, в пищевой и фармацевтической промышленностях, строительстве, сельском хозяйстве, обработке металлов. Наш завод производит котельные мощностью до 40 тонн пара в час. Современные паровые котельные оснащаются полным комплексом оборудования автоматизации, контроля и управления процессами, что делает их совершенно безопасными и надежными при эксплуатации.</p>
                      <p>Паровые котельные благодаря большому количеству тепловой энергии, вырабатываемой в процессе получения пара, в ряде случаев используются также  для отопления и ГВС производственных помещений.</p>
                    </div>
                  </div>
                </div>
                <div class="banner-right steam-right">
                  <form class="form form-banner form-banner__smoke form-float form-js form-test" enctype="multipart/form-data" method="post" id="form5" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                    <div class="form-float__img"><img src="<?php echo MAG_IMG_DIR?>/general/redF.png" alt=""></div><span class="form-banner-title">Рассчитать котельную</span>
                    <hr class="form-banner-line">
                    <div class="form-banner-wrapper form-hide">
                      <div class="form-banner-group">
                        <input class="validate" type="text" placeholder="Имя" name="nameFF">
                      </div>
                      <div class="form-banner-group">
                        <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                      </div>
                      <div class="form-banner-group">
                        <input type="text" placeholder="Почта" name="emailFF">
                      </div>
                      <div class="form-banner-btn">
                        <button class="btn btn-banner-form form-button">Рассчитать</button>
                        <input class="form-metka" type="hidden" name="metkaFF" value="Рассчитать котельную">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                      </div>
                      <div class="form-b-radio popup-form__check" style="displaY:none"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked" name="checked">
<span class="checkmark"></span>
</label>
                      </div>
                    </div>
                    <div class="popup-form--wrap form-ok form-test-ok">
                      <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-tipes">
          <div class="container">
            <div class="tipes">
              <h2 class="sec-title">Типы котельных</h2>
              <div class="tipes-items df sb">
                <div class="tipes-item">
                  <div class="tipes-item__top"><img src="<?php echo MAG_IMG_DIR?>/general/st1.png" alt=""></div>
                  <div class="tipes-item__text"><span>Нефтехимическая и химическая промышленность:</span>
                    <p>Нефтепереработка, химические комбинаты, лакокрасочные предприятия.</p>
                  </div>
                </div>
                <div class="tipes-item">
                  <div class="tipes-item__top"><img src="<?php echo MAG_IMG_DIR?>/general/st2.png" alt=""></div>
                  <div class="tipes-item__text"><span>Пищевые продукты и напитки:</span>
                    <p>Обработка зерновых культур, молочные комбинаты, кондитерские фабрики, пивоварни.</p>
                  </div>
                </div>
                <div class="tipes-item">
                  <div class="tipes-item__top"><img src="<?php echo MAG_IMG_DIR?>/general/st3.png" alt=""></div>
                  <div class="tipes-item__text"><span>Производство материалов и оборудования:</span>
                    <p>Текстиль, кабельная продукция, стройматериалы, производство бумаги, металлов, резины, пластика, деревообработка.</p>
                  </div>
                </div>
                <div class="tipes-item">
                  <div class="tipes-item__top"><img src="<?php echo MAG_IMG_DIR?>/general/st4.png" alt=""></div>
                  <div class="tipes-item__text"><span>Фармацевтические фабрики:</span>
                    <p>Производство лекарственных препаратов, медицинских изделий, дезинфицирующих средств.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="s-form-b sa-form-b sa-form-b-steam">
          <div class="container">
            <div class="form-b-wrapper">
              <form class="form-b form-img form-js form-test" enctype="multipart/form-data" method="post" id="form6" onsubmit="ym(72682954,'reachGoal','ORDER'); gtag('event', 'order', { 'event_category': 'form', 'event_action': 'order', });">
                <div class="form-b-items form-hide">
                  <h2 class="form-b-title">Запросите коммерческое предложение!</h2>
                  <hr class="form-b-line">
                  <p class="form-b-text">И договоритесь о личной встрече на заводе или в вашем городе!</p>
                  <div class="form-b-group df sb">
                    <div class="form-b-group__block">
                      <input class="mask validate" type="text" placeholder="8 (___) ___-__-__" name="telFF">
                    </div>
                    <div class="form-b-group__block">
                      <button class="btn btn-big form-button">Заказать котельную</button>
                      
                      <input class="form-metka" type="hidden" name="metkaFF" value="Запросите коммерческое предложение">

                      <input class="form-city" type="hidden" name="cityFF" value="">
                    </div>
                  </div>
                  <div class="form-b-radio"><label class="check-container confidencial__checked">Нажимая на кнопку "Заказать котельную", Вы соглашаетесь с <a href="">Соглашением на обработку персональных данных</a>
<input type="checkbox" checked="checked">
<span class="checkmark"></span>
</label>
                  </div>
                </div>
                <div class="form-img__wrapper steam-form__img"><img src="<?php echo MAG_IMG_DIR?>/general/fr1.png" alt=""></div>
                <div class="popup-form--wrap form-ok form-test-ok">
                  <div class="popup-form__title">Спасибо за заявку<br>мы свяжемся с вами в ближайшее время</div>
                </div>
              </form>
            </div>
          </div>
        </section>
      </div>
     
<?php get_footer();?>