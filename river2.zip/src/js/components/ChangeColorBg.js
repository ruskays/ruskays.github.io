
import changeBg from './ChangeColorBg/_changeBg'
import stickyHeader from './ChangeColorBg/_styckyHeader'

export default function changeColorBg() {
    window.onscroll = function () {
        //stiky header
        stickyHeader()
        //смена bg
        changeBg()
    }
}