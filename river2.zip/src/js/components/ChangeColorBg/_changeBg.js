//смена bg
export default function changeBg() {

    //смена bg
    let elBg = document.querySelector('._bgChange');
    let comBg = document.querySelector('.comment__photo-big');
    
    //цвета
    let _сolor1 =  '#1F2032';
    let _сolor2 = '#312DFF';

    if(elBg !== null) {
        elBg.style.backgroundColor = _сolor1;
    }

    let scroll = window.pageYOffset;
    if(elBg !== null && comBg !== null) {
        if (scroll < 1000) {
            elBg.style.backgroundColor = _сolor1;
            comBg.style.backgroundColor = _сolor2;
        } else {
            elBg.style.backgroundColor = _сolor2;
            comBg.style.backgroundColor = _сolor1;
        }
        if( window.innerWidth < 1300 && scroll < 600){
            elBg.style.backgroundColor = _сolor1;
            comBg.style.backgroundColor = _сolor2;
        } else if(window.innerWidth < 1300 && scroll > 600){
            elBg.style.backgroundColor = _сolor2;
            comBg.style.backgroundColor = _сolor1;
        }
    }
}