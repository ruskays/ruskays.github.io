 //sticky header
 export default function stickyHeader() {

    let header = document.querySelector(".header");
    
     if(header !== null) {
         let sticky = header.offsetTop;
         if (window.pageYOffset > sticky) {
             header.classList.add("sticky");
         } else {
             header.classList.remove("sticky");
         }
     }
 }

 
 
 