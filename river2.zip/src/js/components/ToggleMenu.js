//menu toggle
export default function toggleMenu() {
    let sandwich = document.querySelector('.menu-toggler');
    let bodyOpen = document.querySelector('.body');
    if(sandwich !== null) {
        sandwich.addEventListener('click', () => {
            bodyOpen.classList.toggle('menu-open');
        })
    }
}
