module.exports = {
    semi: false,
    tabWidth: 4,
    useTabs: false,
    printWidth: 100,
    endOfLine: 'auto',
    singleQuote: true,
    trailingComma: 'es5',
    bracketSpacing: true,
    arrowParens: 'always',
    singleAttributePerLine: true,
}
